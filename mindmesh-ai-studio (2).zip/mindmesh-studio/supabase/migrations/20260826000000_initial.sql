create extension if not exists "pgcrypto";
create table public.profiles(
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  plan text not null default 'creator' check(plan in('creator','pro','business')),
  daily_limit integer not null default 50 check(daily_limit between 1 and 10000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.generations(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check(kind in('text','image','video')),
  provider text not null check(provider in('openai','google','demo')),
  prompt text not null check(char_length(prompt) between 3 and 4000),
  enhanced_prompt text,
  model text not null,
  status text not null default 'queued' check(status in('queued','processing','completed','failed')),
  output_text text,
  storage_path text,
  thumbnail_path text,
  provider_job_id text,
  settings jsonb not null default '{}'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  error text,
  favorite boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz
);
create table public.usage_events(
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  generation_id uuid references public.generations(id) on delete set null,
  kind text not null check(kind in('text','image','video')),
  provider text not null,
  units integer not null default 1 check(units>0),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index generations_user_created_idx on public.generations(user_id,created_at desc);
create index generations_user_kind_idx on public.generations(user_id,kind);
create index generations_processing_idx on public.generations(status,updated_at) where status='processing';
create index usage_user_day_idx on public.usage_events(user_id,created_at desc);
alter table public.profiles enable row level security;
alter table public.generations enable row level security;
alter table public.usage_events enable row level security;
create policy "profile select own" on public.profiles for select using(auth.uid()=id);
create policy "profile update own" on public.profiles for update using(auth.uid()=id) with check(auth.uid()=id);
create policy "generation select own" on public.generations for select using(auth.uid()=user_id);
create policy "generation insert own" on public.generations for insert with check(auth.uid()=user_id);
create policy "generation update own" on public.generations for update using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "generation delete own" on public.generations for delete using(auth.uid()=user_id);
create policy "usage select own" on public.usage_events for select using(auth.uid()=user_id);
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('generations','generations',false,524288000,array['image/png','image/jpeg','image/webp','video/mp4'])
on conflict(id)do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
create policy "asset select own" on storage.objects for select using(bucket_id='generations' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "asset insert own" on storage.objects for insert with check(bucket_id='generations' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "asset delete own" on storage.objects for delete using(bucket_id='generations' and (storage.foldername(name))[1]=auth.uid()::text);
create or replace function public.touch_updated_at()returns trigger language plpgsql as $$begin new.updated_at=now();return new;end$$;
create trigger profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();
create trigger generations_touch before update on public.generations for each row execute function public.touch_updated_at();
create or replace function public.create_profile_for_new_user()returns trigger security definer set search_path=public language plpgsql as $$begin insert into public.profiles(id,display_name)values(new.id,coalesce(new.raw_user_meta_data->>'display_name',split_part(new.email,'@',1)));return new;end$$;
create trigger auth_user_profile after insert on auth.users for each row execute function public.create_profile_for_new_user();
create or replace function public.my_daily_usage()returns table(text_count bigint,image_count bigint,video_count bigint,total_count bigint,daily_limit integer)security definer set search_path=public language sql as $$
  select count(*)filter(where u.kind='text'),count(*)filter(where u.kind='image'),count(*)filter(where u.kind='video'),count(*),coalesce(p.daily_limit,50)
  from public.profiles p left join public.usage_events u on u.user_id=p.id and u.created_at>=date_trunc('day',now())
  where p.id=auth.uid() group by p.daily_limit
$$;
