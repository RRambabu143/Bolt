export const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
export const security = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "no-referrer",
};
export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...cors,
      ...security,
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    },
  });
}
export function safeError(error: unknown) {
  const message = error instanceof Error ? error.message : "Unknown error";
  console.error(error);
  return message
    .replace(/(sk-[A-Za-z0-9_-]+|AIza[A-Za-z0-9_-]+)/g, "[redacted]")
    .slice(0, 1200);
}
export async function body<T>(req: Request) {
  const length = Number(req.headers.get("content-length") || 0);
  if (length > 25000) throw new Error("Request is too large");
  return (await req.json()) as T;
}
