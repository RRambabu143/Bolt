import type { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";
export function bytes(base64: string) {
  return Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
}
export async function store(
  admin: SupabaseClient,
  userId: string,
  id: string,
  data: Uint8Array,
  mime: string,
  extension: string,
) {
  const path = userId + "/" + id + "." + extension;
  const { error } = await admin.storage
    .from("generations")
    .upload(path, data, {
      contentType: mime,
      upsert: true,
      cacheControl: "31536000",
    });
  if (error) throw error;
  return path;
}
export async function signed(
  admin: SupabaseClient,
  path: string | null,
  expires = 3600,
) {
  if (!path) return null;
  const { data, error } = await admin.storage
    .from("generations")
    .createSignedUrl(path, expires);
  if (error) throw error;
  return data.signedUrl;
}
export async function remove(admin: SupabaseClient, path: string | null) {
  if (!path) return;
  const { error } = await admin.storage.from("generations").remove([path]);
  if (error) throw error;
}
