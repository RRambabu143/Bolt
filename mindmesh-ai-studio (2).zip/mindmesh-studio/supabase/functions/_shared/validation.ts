export type Kind = "text" | "image" | "video";
const KINDS: Kind[] = ["text", "image", "video"],
  RATIOS = ["1:1", "4:3", "3:4", "16:9", "9:16"],
  VIDEO_RATIOS = ["16:9", "9:16"],
  RESOLUTIONS = ["720p", "1080p", "4k"];
export function generationInput(value: any) {
  if (!value || !KINDS.includes(value.kind))
    throw new Error("Invalid generation type");
  if (
    typeof value.prompt !== "string" ||
    value.prompt.trim().length < 3 ||
    value.prompt.length > 4000
  )
    throw new Error("Prompt must contain 3 to 4,000 characters");
  const kind = value.kind as Kind,
    s =
      value.settings && typeof value.settings === "object"
        ? value.settings
        : {};
  if (kind === "text")
    return {
      kind,
      prompt: value.prompt.trim(),
      settings: {
        tone: String(s.tone || "Professional").slice(0, 50),
        format: String(s.format || "Article").slice(0, 50),
        creativity: Math.max(0, Math.min(100, Number(s.creativity) || 60)),
      },
    };
  if (kind === "image")
    return {
      kind,
      prompt: value.prompt.trim(),
      settings: {
        aspect_ratio: RATIOS.includes(s.aspect_ratio) ? s.aspect_ratio : "1:1",
        negative_prompt: String(s.negative_prompt || "").slice(0, 500),
        seed: Number.isSafeInteger(s.seed) ? s.seed : undefined,
      },
    };
  return {
    kind,
    prompt: value.prompt.trim(),
    settings: {
      aspect_ratio: VIDEO_RATIOS.includes(s.aspect_ratio)
        ? s.aspect_ratio
        : "16:9",
      resolution: RESOLUTIONS.includes(s.resolution) ? s.resolution : "720p",
      duration_seconds: [4, 6, 8].includes(Number(s.duration_seconds))
        ? Number(s.duration_seconds)
        : 8,
      include_audio: s.include_audio !== false,
      reference_image_url:
        typeof s.reference_image_url === "string"
          ? s.reference_image_url.slice(0, 2000)
          : undefined,
    },
  };
}
export function uuid(value: unknown) {
  if (
    typeof value !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      value,
    )
  )
    throw new Error("Invalid generation id");
  return value;
}
