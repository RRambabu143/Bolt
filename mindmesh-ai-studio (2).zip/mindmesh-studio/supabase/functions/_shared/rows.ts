import type { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";
import { signed } from "./storage.ts";
export async function present(admin: SupabaseClient, row: any) {
  return {
    ...row,
    asset_url: await signed(admin, row.storage_path),
    thumbnail_url: await signed(admin, row.thumbnail_path),
  };
}
export async function update(
  admin: SupabaseClient,
  id: string,
  values: Record<string, unknown>,
) {
  const { data, error } = await admin
    .from("generations")
    .update(values)
    .eq("id", id)
    .select()
    .single();
  if (error) throw error;
  return present(admin, data);
}
