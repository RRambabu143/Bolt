import {
  createClient,
  User,
} from "https://esm.sh/@supabase/supabase-js@2.57.4";
export async function context(req: Request) {
  const url = Deno.env.get("SUPABASE_URL"),
    anon = Deno.env.get("SUPABASE_ANON_KEY"),
    service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anon || !service)
    throw new Error("Server configuration is incomplete");
  const authorization = req.headers.get("Authorization") || "";
  if (!authorization.startsWith("Bearer ")) throw new Error("Unauthorized");
  const client = createClient(url, anon, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false },
  });
  const { data, error } = await client.auth.getUser();
  if (error || !data.user) throw new Error("Unauthorized");
  return {
    user: data.user as User,
    client,
    admin: createClient(url, service, { auth: { persistSession: false } }),
  };
}
