import type { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";
export async function enforceQuota(admin: SupabaseClient, userId: string) {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const [{ count, error }, { data: profile }] = await Promise.all([
    admin
      .from("usage_events")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)
      .gte("created_at", start.toISOString()),
    admin.from("profiles").select("daily_limit").eq("id", userId).maybeSingle(),
  ]);
  if (error) throw error;
  const limit = profile?.daily_limit ?? 50;
  if ((count ?? 0) >= limit) throw new Error("Daily generation limit reached");
  return { used: count ?? 0, limit };
}
export async function recordUsage(
  admin: SupabaseClient,
  userId: string,
  generationId: string,
  kind: string,
  provider: string,
  metadata: Record<string, unknown> = {},
) {
  const { error } = await admin
    .from("usage_events")
    .insert({
      user_id: userId,
      generation_id: generationId,
      kind,
      provider,
      metadata,
    });
  if (error) throw error;
}
