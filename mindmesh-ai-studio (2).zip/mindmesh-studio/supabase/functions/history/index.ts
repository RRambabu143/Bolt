import { context } from "../_shared/auth.ts";
import { body, cors, json, safeError } from "../_shared/http.ts";
import { present } from "../_shared/rows.ts";
import { remove } from "../_shared/storage.ts";
import { uuid } from "../_shared/validation.ts";
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { user, admin } = await context(req),
      input = await body<any>(req);
    if (input.action === "list") {
      let query = admin
        .from("generations")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(100);
      if (["text", "image", "video"].includes(input.filter))
        query = query.eq("kind", input.filter);
      if (input.filter === "favorites") query = query.eq("favorite", true);
      if (typeof input.search === "string" && input.search.trim())
        query = query.ilike(
          "prompt",
          "%" + input.search.trim().replace(/[%_]/g, "") + "%",
        );
      const { data, error } = await query;
      if (error) throw error;
      return json({
        generations: await Promise.all(
          (data || []).map((row) => present(admin, row)),
        ),
      });
    }
    if (input.action === "usage") {
      const start = new Date();
      start.setUTCHours(0, 0, 0, 0);
      const [{ data, error }, { data: profile }] = await Promise.all([
        admin
          .from("usage_events")
          .select("kind")
          .eq("user_id", user.id)
          .gte("created_at", start.toISOString()),
        admin
          .from("profiles")
          .select("daily_limit")
          .eq("id", user.id)
          .maybeSingle(),
      ]);
      if (error) throw error;
      const events = data || [],
        count = (kind: string) => events.filter((x) => x.kind === kind).length,
        limit = profile?.daily_limit ?? 50;
      return json({
        usage: {
          text: count("text"),
          image: count("image"),
          video: count("video"),
          total: events.length,
          daily_limit: limit,
          remaining: Math.max(0, limit - events.length),
        },
      });
    }
    const id = uuid(input.id);
    const { data: row, error } = await admin
      .from("generations")
      .select("*")
      .eq("id", id)
      .eq("user_id", user.id)
      .single();
    if (error) throw error;
    if (input.action === "favorite") {
      const { data, error: updateError } = await admin
        .from("generations")
        .update({ favorite: Boolean(input.favorite) })
        .eq("id", id)
        .select()
        .single();
      if (updateError) throw updateError;
      return json({ generation: await present(admin, data) });
    }
    if (input.action === "delete") {
      await remove(admin, row.storage_path);
      await remove(admin, row.thumbnail_path);
      const { error: deleteError } = await admin
        .from("generations")
        .delete()
        .eq("id", id);
      if (deleteError) throw deleteError;
      return json({ deleted: true });
    }
    throw new Error("Invalid history action");
  } catch (error) {
    const message = safeError(error);
    return json({ error: message }, message === "Unauthorized" ? 401 : 400);
  }
});
