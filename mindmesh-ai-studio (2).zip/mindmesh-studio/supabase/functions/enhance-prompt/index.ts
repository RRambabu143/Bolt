import { context } from "../_shared/auth.ts";
import { body, cors, json, safeError } from "../_shared/http.ts";
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    await context(req);
    const { prompt, kind } = await body<{ prompt: string; kind: string }>(req);
    if (
      typeof prompt !== "string" ||
      prompt.trim().length < 3 ||
      prompt.length > 4000
    )
      throw new Error("Prompt must contain 3 to 4,000 characters");
    if (!["text", "image", "video"].includes(kind))
      throw new Error("Invalid generation type");
    const key = Deno.env.get("OPENAI_API_KEY");
    if (!key) throw new Error("OPENAI_API_KEY is not configured");
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + key,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: Deno.env.get("OPENAI_TEXT_MODEL") || "gpt-5.6",
        instructions:
          "Rewrite the user idea into one production-ready " +
          kind +
          " generation prompt. Preserve intent. Add useful concrete detail. For video include camera, action, lighting, pacing and sound. For image include composition, lens, light and finish. For text include audience, structure and tone. Return only the enhanced prompt under 1,500 characters.",
        input: prompt,
        store: false,
      }),
    });
    if (!response.ok)
      throw new Error(
        "Prompt enhancement failed (" +
          response.status +
          "): " +
          (await response.text()),
      );
    const payload = await response.json(),
      output =
        payload.output_text ||
        payload.output
          ?.flatMap((i: any) => i.content || [])
          .map((p: any) => p.text || "")
          .join("");
    if (!output) throw new Error("No enhanced prompt returned");
    return json({ prompt: output.trim() });
  } catch (error) {
    const message = safeError(error);
    return json({ error: message }, message === "Unauthorized" ? 401 : 400);
  }
});
