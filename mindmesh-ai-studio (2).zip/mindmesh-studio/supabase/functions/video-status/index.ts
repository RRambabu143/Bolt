import { context } from "../_shared/auth.ts";
import { body, cors, json, safeError } from "../_shared/http.ts";
import { present, update } from "../_shared/rows.ts";
import { store } from "../_shared/storage.ts";
import { uuid } from "../_shared/validation.ts";
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { user, admin } = await context(req),
      { id } = await body<{ id: string }>(req);
    uuid(id);
    const { data: row, error } = await admin
      .from("generations")
      .select("*")
      .eq("id", id)
      .eq("user_id", user.id)
      .single();
    if (error) throw error;
    if (row.kind !== "video") throw new Error("This generation is not a video");
    if (row.status === "completed" || row.status === "failed")
      return json({ generation: await present(admin, row) });
    if (!row.provider_job_id) throw new Error("Video operation is missing");
    const key = Deno.env.get("GOOGLE_AI_API_KEY");
    if (!key) throw new Error("GOOGLE_AI_API_KEY is not configured");
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/" +
        row.provider_job_id +
        "?key=" +
        key,
    );
    if (!response.ok)
      throw new Error(
        "Veo status request failed (" +
          response.status +
          "): " +
          (await response.text()),
      );
    const operation = await response.json();
    if (!operation.done) return json({ generation: await present(admin, row) });
    if (operation.error)
      return json({
        generation: await update(admin, id, {
          status: "failed",
          error: operation.error.message || "Veo could not generate this video",
        }),
      });
    const video =
      operation.response?.generateVideoResponse?.generatedSamples?.[0]?.video ||
      operation.response?.generatedVideos?.[0]?.video;
    let uri = video?.uri || video?.videoUri;
    if (!uri) throw new Error("Veo completed without a downloadable video");
    if (!uri.includes("key="))
      uri += (uri.includes("?") ? "&" : "?") + "key=" + key;
    const download = await fetch(uri);
    if (!download.ok)
      throw new Error("Video download failed (" + download.status + ")");
    const path = await store(
      admin,
      user.id,
      id,
      new Uint8Array(await download.arrayBuffer()),
      "video/mp4",
      "mp4",
    );
    return json({
      generation: await update(admin, id, {
        status: "completed",
        storage_path: path,
        completed_at: new Date().toISOString(),
        metadata: {
          ...row.metadata,
          provider_response: operation.response?.metadata || null,
        },
      }),
    });
  } catch (error) {
    const message = safeError(error);
    return json({ error: message }, message === "Unauthorized" ? 401 : 400);
  }
});
