import { context } from "../_shared/auth.ts";
import { body, cors, json, safeError } from "../_shared/http.ts";
import { enforceQuota, recordUsage } from "../_shared/quota.ts";
import { update } from "../_shared/rows.ts";
import { bytes, store } from "../_shared/storage.ts";
import { generationInput } from "../_shared/validation.ts";
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let generationId: string | undefined;
  try {
    const { user, admin } = await context(req);
    await enforceQuota(admin, user.id);
    const input = generationInput(await body(req));
    const provider = input.kind === "text" ? "openai" : "google";
    const model =
      input.kind === "text"
        ? Deno.env.get("OPENAI_TEXT_MODEL") || "gpt-5.6"
        : input.kind === "image"
          ? Deno.env.get("GOOGLE_IMAGE_MODEL") || "gemini-3.1-flash-image"
          : Deno.env.get("GOOGLE_VIDEO_MODEL") || "veo-3.1-generate-preview";
    const { data: created, error } = await admin
      .from("generations")
      .insert({
        user_id: user.id,
        kind: input.kind,
        provider,
        prompt: input.prompt,
        model,
        status: "processing",
        settings: input.settings,
      })
      .select()
      .single();
    if (error) throw error;
    generationId = created.id;
    if (input.kind === "text") {
      const key = Deno.env.get("OPENAI_API_KEY");
      if (!key) throw new Error("OPENAI_API_KEY is not configured");
      const instructions = [
        "You are the writing engine inside MindMesh AI Studio.",
        "Produce only the requested deliverable with no meta commentary.",
        "Format: " + input.settings.format + ".",
        "Tone: " + input.settings.tone + ".",
        "Creativity level: " + input.settings.creativity + "/100.",
      ].join("\n");
      const response = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
          Authorization: "Bearer " + key,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          input: input.prompt,
          instructions,
          store: false,
        }),
      });
      if (!response.ok)
        throw new Error(
          "OpenAI request failed (" +
            response.status +
            "): " +
            (await response.text()),
        );
      const payload = await response.json();
      const output =
        payload.output_text ||
        payload.output
          ?.flatMap((item: any) => item.content || [])
          .filter((part: any) => part.type === "output_text")
          .map((part: any) => part.text)
          .join("") ||
        "";
      if (!output) throw new Error("OpenAI returned an empty response");
      await recordUsage(admin, user.id, generationId, input.kind, provider, {
        model,
      });
      return json({
        generation: await update(admin, generationId, {
          status: "completed",
          output_text: output,
          completed_at: new Date().toISOString(),
          metadata: { response_id: payload.id, usage: payload.usage },
        }),
      });
    }
    const googleKey = Deno.env.get("GOOGLE_AI_API_KEY");
    if (!googleKey) throw new Error("GOOGLE_AI_API_KEY is not configured");
    if (input.kind === "image") {
      const finalPrompt = input.settings.negative_prompt
        ? input.prompt + "\nAvoid: " + input.settings.negative_prompt
        : input.prompt;
      const response = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/" +
          model +
          ":generateContent?key=" +
          googleKey,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: finalPrompt }] }],
            generationConfig: {
              responseModalities: ["IMAGE"],
              imageConfig: { aspectRatio: input.settings.aspect_ratio },
            },
          }),
        },
      );
      if (!response.ok)
        throw new Error(
          "Google image request failed (" +
            response.status +
            "): " +
            (await response.text()),
        );
      const payload = await response.json();
      const part = payload.candidates?.[0]?.content?.parts?.find(
        (entry: any) => entry.inlineData?.data,
      );
      if (!part) throw new Error("Google returned no image");
      const mime = part.inlineData.mimeType || "image/png",
        extension = mime.includes("jpeg")
          ? "jpg"
          : mime.includes("webp")
            ? "webp"
            : "png",
        path = await store(
          admin,
          user.id,
          generationId,
          bytes(part.inlineData.data),
          mime,
          extension,
        );
      await recordUsage(admin, user.id, generationId, input.kind, provider, {
        model,
      });
      return json({
        generation: await update(admin, generationId, {
          status: "completed",
          storage_path: path,
          completed_at: new Date().toISOString(),
          metadata: { finish_reason: payload.candidates?.[0]?.finishReason },
        }),
      });
    }
    const parameters: any = {
      aspectRatio: input.settings.aspect_ratio,
      resolution: input.settings.resolution,
      durationSeconds: input.settings.duration_seconds,
      sampleCount: 1,
      generateAudio: input.settings.include_audio,
    };
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/" +
        model +
        ":predictLongRunning?key=" +
        googleKey,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instances: [{ prompt: input.prompt }],
          parameters,
        }),
      },
    );
    if (!response.ok)
      throw new Error(
        "Veo request failed (" +
          response.status +
          "): " +
          (await response.text()),
      );
    const operation = await response.json();
    if (!operation.name) throw new Error("Veo returned no operation id");
    await recordUsage(admin, user.id, generationId, input.kind, provider, {
      model,
      operation: operation.name,
    });
    return json(
      {
        generation: await update(admin, generationId, {
          provider_job_id: operation.name,
          metadata: { poll_after_seconds: 10 },
        }),
      },
      202,
    );
  } catch (error) {
    const message = safeError(error);
    if (generationId)
      try {
        const { admin } = await context(req);
        await admin
          .from("generations")
          .update({ status: "failed", error: message })
          .eq("id", generationId);
      } catch {}
    return json({ error: message }, message === "Unauthorized" ? 401 : 400);
  }
});
